// DebugScreen — developer-only validation checklist, consistency checks, and data reset tools
import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import React from "react";
import {
  Alert,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { getVocabStats, getWordById, MOCK_WORDS } from "@/constants/mockData";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";

export default function DebugScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const {
    reviews, savedWords, customWords, findWord,
    resetSavedWords, resetReviews, resetCustomWords, resetStudyProgress, resetAll,
  } = useApp();
  const topPad = Platform.OS === "web" ? 67 : insets.top;

  const stats = getVocabStats();

  // ── Dataset checks ───────────────────────────────────────────────────────
  const testWord = getWordById("e25");
  const wordDetailOk = !!testWord && testWord.word === "friend";
  const wordsWithMissingFields = MOCK_WORDS.filter(
    (w) => !w.word || !w.meaning || !w.pronunciation || !w.example || !w.memoryTip
  );
  const wordIds = MOCK_WORDS.map((w) => w.id);
  const duplicateIds = wordIds.filter((id, i) => wordIds.indexOf(id) !== i);

  // ── Custom word checks ───────────────────────────────────────────────────
  const findWordDatasetOk = !!findWord("e25");
  const findWordCustomOk =
    customWords.length === 0 ? true : !!findWord(customWords[0].id);
  const memorizationOk = reviews.length >= 0;
  const customInSearchOk =
    customWords.length === 0
      ? true
      : savedWords.some((s) => s.wordId === customWords[0].id);
  const customInReviewOk =
    customWords.length === 0
      ? true
      : reviews.some((r) => r.wordId === customWords[0].id);

  // ── Data consistency checks ──────────────────────────────────────────────
  // Orphan = entry whose wordId can't be resolved by findWord
  const orphanSavedWords = savedWords.filter((s) => !findWord(s.wordId));
  const orphanReviews = reviews.filter((r) => !findWord(r.wordId));
  const customWordIds = customWords.map((w) => w.id);
  const duplicateCustomIds = customWordIds.filter(
    (id, i) => customWordIds.indexOf(id) !== i
  );

  // ── Checks array ─────────────────────────────────────────────────────────
  const checks: { label: string; value: string; ok: boolean }[] = [
    {
      label: "전체 단어 수",
      value: `${stats.total}개 (목표: 300)`,
      ok: stats.total === 300,
    },
    {
      label: "초등 단어 수",
      value: `${stats.elementaryCount}개 (목표: 100)`,
      ok: stats.elementaryCount === 100,
    },
    {
      label: "중등 단어 수",
      value: `${stats.middleCount}개 (목표: 100)`,
      ok: stats.middleCount === 100,
    },
    {
      label: "고등 단어 수",
      value: `${stats.highCount}개 (목표: 100)`,
      ok: stats.highCount === 100,
    },
    {
      label: "카메라 데모 단어 매칭",
      value: `${stats.demoMatched}/${stats.demoTotal}개 (데이터셋 내 8개)`,
      ok: stats.demoMatched === 8,
    },
    {
      label: "중복 ID (데이터셋)",
      value: duplicateIds.length === 0 ? "없음" : duplicateIds.join(", "),
      ok: duplicateIds.length === 0,
    },
    {
      label: "필수 필드 누락 단어",
      value:
        wordsWithMissingFields.length === 0
          ? "없음"
          : wordsWithMissingFields.map((w) => w.id).join(", "),
      ok: wordsWithMissingFields.length === 0,
    },
    {
      label: "단어 상세 화면 연결",
      value: wordDetailOk
        ? `정상 (id=e25 → "${testWord?.word}")`
        : "오류: getWordById 실패",
      ok: wordDetailOk,
    },
    {
      label: "암기 화면 연결",
      value: memorizationOk
        ? `정상 (복습 큐 ${reviews.length}개)`
        : "오류",
      ok: memorizationOk,
    },
    {
      label: "복습 스케줄 저장",
      value: `정상 (저장됨 ${savedWords.length}개, 복습 ${reviews.length}개)`,
      ok: true,
    },
    // ── Custom word checks ─────────────────────────────────────────────────
    {
      label: "커스텀 단어 수",
      value: `${customWords.length}개 저장됨`,
      ok: true,
    },
    {
      label: "커스텀 단어 findWord 조회",
      value:
        findWordDatasetOk && findWordCustomOk
          ? "정상 (데이터셋 + 커스텀 모두 조회 가능)"
          : "오류: findWord 실패",
      ok: findWordDatasetOk && findWordCustomOk,
    },
    {
      label: "커스텀 단어 → 저장됨 탭 연결",
      value: customInSearchOk
        ? customWords.length === 0
          ? "커스텀 단어 없음 (저장하면 자동 표시)"
          : `정상 (${customWords.length}개 확인)`
        : "오류: savedWords 미포함",
      ok: customInSearchOk,
    },
    {
      label: "커스텀 단어 → 복습 스케줄 연결",
      value: customInReviewOk
        ? customWords.length === 0
          ? "커스텀 단어 없음 (저장하면 자동 등록)"
          : `정상 (${customWords.length}개 복습 큐 포함)`
        : "오류: reviews 미포함",
      ok: customInReviewOk,
    },
    {
      label: "커스텀 단어 isCustom 필드",
      value: customWords.every((w) => w.isCustom === true)
        ? customWords.length === 0
          ? "커스텀 단어 없음"
          : "정상 (모든 커스텀 단어 isCustom=true)"
        : "오류: isCustom 누락",
      ok: customWords.every((w) => w.isCustom === true),
    },
    // ── Data consistency ───────────────────────────────────────────────────
    {
      label: "고아 savedWords 감지",
      value:
        orphanSavedWords.length === 0
          ? "없음"
          : `${orphanSavedWords.length}개: ${orphanSavedWords.map((s) => s.wordId).join(", ")}`,
      ok: orphanSavedWords.length === 0,
    },
    {
      label: "고아 복습 항목 감지",
      value:
        orphanReviews.length === 0
          ? "없음"
          : `${orphanReviews.length}개: ${orphanReviews.map((r) => r.wordId).join(", ")}`,
      ok: orphanReviews.length === 0,
    },
    {
      label: "커스텀 단어 중복 ID",
      value:
        duplicateCustomIds.length === 0
          ? "없음"
          : duplicateCustomIds.join(", "),
      ok: duplicateCustomIds.length === 0,
    },
  ];

  const passCount = checks.filter((c) => c.ok).length;
  const allPass = passCount === checks.length;

  // ── Reset button definitions ──────────────────────────────────────────────
  const resetActions = [
    {
      label: "저장 목록 초기화",
      desc: `저장된 단어 ${savedWords.length}개`,
      color: colors.info,
      fn: resetSavedWords,
    },
    {
      label: "복습 일정 초기화",
      desc: `복습 항목 ${reviews.length}개`,
      color: colors.accent,
      fn: resetReviews,
    },
    {
      label: "커스텀 단어 초기화",
      desc: `커스텀 단어 ${customWords.length}개`,
      color: colors.hard,
      fn: resetCustomWords,
    },
    {
      label: "학습 진도 초기화",
      desc: "스트릭 · 통계 · 완료 단원",
      color: colors.mutedForeground,
      fn: resetStudyProgress,
    },
    {
      label: "⚠️ 전체 초기화",
      desc: "모든 로컬 데이터 삭제",
      color: colors.hard,
      fn: resetAll,
    },
  ];

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View
        style={[
          styles.header,
          { paddingTop: topPad + 8, borderBottomColor: colors.border },
        ]}
      >
        <TouchableOpacity onPress={() => router.back()} hitSlop={12}>
          <Ionicons name="arrow-back" size={24} color={colors.foreground} />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>
          개발자 검증
        </Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView
        contentContainerStyle={[styles.content, { paddingBottom: 60 }]}
        showsVerticalScrollIndicator={false}
      >
        {/* Summary badge */}
        <View
          style={[
            styles.summaryCard,
            {
              backgroundColor: allPass ? colors.primary + "12" : colors.hard + "12",
              borderColor: allPass ? colors.primary + "44" : colors.hard + "44",
              borderRadius: colors.radius,
            },
          ]}
        >
          <Ionicons
            name={allPass ? "checkmark-circle" : "warning"}
            size={36}
            color={allPass ? colors.primary : colors.hard}
          />
          <Text style={[styles.summaryTitle, { color: colors.foreground }]}>
            {passCount} / {checks.length} 검증 통과
          </Text>
          <Text style={[styles.summaryDesc, { color: colors.mutedForeground }]}>
            {allPass ? "모든 항목이 정상입니다!" : "일부 항목에 문제가 있습니다."}
          </Text>
        </View>

        {/* Checklist */}
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
          체크리스트
        </Text>
        <View
          style={[
            styles.checkList,
            {
              backgroundColor: colors.card,
              borderColor: colors.border,
              borderRadius: colors.radius,
            },
          ]}
        >
          {checks.map((c, i) => (
            <View
              key={c.label}
              style={[
                styles.checkItem,
                i < checks.length - 1 && {
                  borderBottomWidth: 1,
                  borderBottomColor: colors.border,
                },
              ]}
            >
              <Ionicons
                name={c.ok ? "checkmark-circle" : "close-circle"}
                size={18}
                color={c.ok ? colors.primary : colors.hard}
              />
              <View style={styles.checkBody}>
                <Text style={[styles.checkLabel, { color: colors.foreground }]}>
                  {c.label}
                </Text>
                <Text
                  style={[styles.checkValue, { color: colors.mutedForeground }]}
                >
                  {c.value}
                </Text>
              </View>
            </View>
          ))}
        </View>

        {/* Unit breakdown */}
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
          단원별 단어 수
        </Text>
        <View
          style={[
            styles.checkList,
            {
              backgroundColor: colors.card,
              borderColor: colors.border,
              borderRadius: colors.radius,
            },
          ]}
        >
          {Object.entries(stats.unitCounts)
            .sort(([a], [b]) => a.localeCompare(b))
            .map(([key, count], i, arr) => {
              const [level, grade, unit] = key.split("-");
              const levelLabel =
                level === "elementary"
                  ? "초등"
                  : level === "middle"
                  ? "중등"
                  : "고등";
              return (
                <View
                  key={key}
                  style={[
                    styles.checkItem,
                    i < arr.length - 1 && {
                      borderBottomWidth: 1,
                      borderBottomColor: colors.border,
                    },
                  ]}
                >
                  <View
                    style={[
                      styles.levelDot,
                      {
                        backgroundColor:
                          level === "elementary"
                            ? colors.primary
                            : level === "middle"
                            ? colors.info
                            : colors.hard,
                      },
                    ]}
                  />
                  <View style={styles.checkBody}>
                    <Text
                      style={[styles.checkLabel, { color: colors.foreground }]}
                    >
                      {levelLabel} {grade.replace("g", "")}학년{" "}
                      {unit.replace("u", "")}단원
                    </Text>
                    <Text
                      style={[
                        styles.checkValue,
                        { color: colors.mutedForeground },
                      ]}
                    >
                      {count}개 단어
                    </Text>
                  </View>
                </View>
              );
            })}
        </View>

        {/* Quick navigation for manual testing */}
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
          흐름 테스트
        </Text>
        <View style={styles.testBtns}>
          {[
            {
              label: "단어 상세 (friend / e25)",
              path: "/word-detail",
              params: { id: "e25" },
            },
            {
              label: "단어 상세 (미등록 단어)",
              path: "/word-detail",
              params: { id: "", word: "perseverance" },
            },
            {
              label: "암기 시작 (achieve / h01)",
              path: "/memorization",
              params: { id: "h01" },
            },
            {
              label: "카메라 스캔 데모",
              path: "/camera",
              params: {},
            },
          ].map((item) => (
            <TouchableOpacity
              key={item.label}
              onPress={() =>
                router.push({
                  pathname: item.path as never,
                  params: item.params,
                })
              }
              style={[
                styles.testBtn,
                {
                  backgroundColor: colors.card,
                  borderColor: colors.border,
                  borderRadius: colors.radius,
                },
              ]}
            >
              <Ionicons
                name="play-circle-outline"
                size={18}
                color={colors.primary}
              />
              <Text style={[styles.testBtnText, { color: colors.foreground }]}>
                {item.label}
              </Text>
              <Ionicons
                name="chevron-forward"
                size={16}
                color={colors.mutedForeground}
              />
            </TouchableOpacity>
          ))}
        </View>

        {/* ── Data reset tools ─────────────────────────────────────────── */}
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
          데이터 초기화
        </Text>
        <Text style={[styles.resetWarning, { color: colors.mutedForeground }]}>
          각 초기화는 되돌릴 수 없습니다. 확인 Alert이 표시됩니다.
        </Text>
        <View style={styles.resetBtns}>
          {resetActions.map((item) => (
            <TouchableOpacity
              key={item.label}
              onPress={() => {
                Alert.alert(
                  item.label,
                  `${item.desc}\n\n정말 초기화할까요? 이 작업은 취소할 수 없습니다.`,
                  [
                    { text: "취소", style: "cancel" },
                    {
                      text: "초기화",
                      style: "destructive",
                      onPress: item.fn,
                    },
                  ]
                );
              }}
              style={[
                styles.resetBtn,
                {
                  borderColor: item.color + "44",
                  backgroundColor: item.color + "0D",
                  borderRadius: colors.radius,
                },
              ]}
            >
              <Ionicons name="trash-outline" size={16} color={item.color} />
              <View style={styles.resetBtnBody}>
                <Text
                  style={[styles.resetBtnLabel, { color: item.color }]}
                >
                  {item.label}
                </Text>
                <Text
                  style={[
                    styles.resetBtnDesc,
                    { color: colors.mutedForeground },
                  ]}
                >
                  {item.desc}
                </Text>
              </View>
              <Ionicons
                name="chevron-forward"
                size={14}
                color={item.color + "88"}
              />
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingBottom: 12,
    borderBottomWidth: 1,
  },
  headerTitle: { fontSize: 17, fontFamily: "NotoSansKR_600SemiBold" },
  content: { padding: 20, gap: 16 },
  summaryCard: {
    borderWidth: 1,
    padding: 24,
    alignItems: "center",
    gap: 8,
  },
  summaryTitle: { fontSize: 22, fontFamily: "NotoSansKR_700Bold" },
  summaryDesc: { fontSize: 14, fontFamily: "NotoSansKR_400Regular" },
  sectionTitle: {
    fontSize: 16,
    fontFamily: "NotoSansKR_700Bold",
    marginTop: 4,
  },
  checkList: { borderWidth: 1, overflow: "hidden" },
  checkItem: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 10,
    padding: 14,
  },
  checkBody: { flex: 1, gap: 2 },
  checkLabel: { fontSize: 14, fontFamily: "NotoSansKR_600SemiBold" },
  checkValue: { fontSize: 12, fontFamily: "NotoSansKR_400Regular" },
  levelDot: { width: 10, height: 10, borderRadius: 5, marginTop: 4 },
  testBtns: { gap: 8 },
  testBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    borderWidth: 1,
    padding: 14,
  },
  testBtnText: { flex: 1, fontSize: 14, fontFamily: "NotoSansKR_500Medium" },
  resetWarning: {
    fontSize: 12,
    fontFamily: "NotoSansKR_400Regular",
    marginTop: -8,
  },
  resetBtns: { gap: 8 },
  resetBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    borderWidth: 1,
    padding: 14,
  },
  resetBtnBody: { flex: 1, gap: 2 },
  resetBtnLabel: { fontSize: 14, fontFamily: "NotoSansKR_600SemiBold" },
  resetBtnDesc: { fontSize: 12, fontFamily: "NotoSansKR_400Regular" },
});
